// src/strategy/positions.ts
import { Bar, Position } from '../types';
import { formatEasternTime } from '../utils/formatting';
import { CONFIG } from '../config/constants';

export class PositionManager {
  private position: Position | null = null;

  hasPosition(): boolean {
    return this.position !== null;
  }

  checkExit(bar: Bar): { exited: boolean; reason?: string } {
    if (!this.position) return { exited: false };

    const time = formatEasternTime(bar.timestamp);
    const { type, stopPrice, targetPrice } = this.position;

    if (type === 'bullish') {
      if (bar.low <= stopPrice) {
        console.log(
          `  → 🚫 STOP-LOSS LONG @ ${time} | stop was ${stopPrice.toFixed(2)}`
        );
        this.position = null;
        return { exited: true, reason: 'stop-loss' };
      }
      if (bar.high >= targetPrice) {
        console.log(
          `  → 🎯 TAKE-PROFIT LONG @ ${time} | target was ${targetPrice.toFixed(
            2
          )}`
        );
        this.position = null;
        return { exited: true, reason: 'take-profit' };
      }
    } else {
      if (bar.high >= stopPrice) {
        console.log(
          `  → 🚫 STOP-LOSS SHORT @ ${time} | stop was ${stopPrice.toFixed(2)}`
        );
        this.position = null;
        return { exited: true, reason: 'stop-loss' };
      }
      if (bar.low <= targetPrice) {
        console.log(
          `  → 🎯 TAKE-PROFIT SHORT @ ${time} | target was ${targetPrice.toFixed(
            2
          )}`
        );
        this.position = null;
        return { exited: true, reason: 'take-profit' };
      }
    }

    return { exited: false };
  }

  enterPosition(signal: 'bullish' | 'bearish', bar: Bar): Position {
    const entry = bar.close;

    // Use dynamic config values instead of hardcoded 3
    const stopDistance = CONFIG.STOP_LOSS;
    const targetDistance = CONFIG.TAKE_PROFIT;

    const stopPrice =
      signal === 'bullish' ? entry - stopDistance : entry + stopDistance;
    const targetPrice =
      signal === 'bullish' ? entry + targetDistance : entry - targetDistance;

    console.log(
      `    → ENTRY SIGNAL: ${signal.toUpperCase()} @ ${formatEasternTime(
        bar.timestamp
      )} | Entry=${entry.toFixed(2)} Stop=${stopPrice.toFixed(
        2
      )} Target=${targetPrice.toFixed(2)}`
    );

    this.position = {
      type: signal,
      entryPrice: entry,
      stopPrice,
      targetPrice,
      timestamp: bar.timestamp,
    };
    return this.position;
  }

  reset(): void {
    this.position = null;
  }
}
